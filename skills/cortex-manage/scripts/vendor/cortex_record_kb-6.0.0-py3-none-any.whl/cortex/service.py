"""Cortex 6 record-KB operations."""

from __future__ import annotations

import os
import hashlib
import stat
import uuid
from contextlib import contextmanager
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Iterator

from .constants import DEFAULT_LAYOUT, DEFAULT_TAGS, RECORD_FIELDS, RECORD_SCHEMA, REGISTRY_FILENAME, ROOT_LOCK_FILENAME, VERSION
from .errors import CortexError, Status, io_error, usage_error, validation_error
from .jsonio import json_bytes, loads_object, read_json_operand
from .locking import writer_lock, workspace_lock_path
from .naming import tag_title_date_name
from .native import (
    checked_scandir,
    copy_conversion,
    copy_regular,
    exists,
    inspect_conversion,
    is_reparse_metadata,
    native_path,
    reject_reparse_ancestry,
    rename_no_replace,
    require_real_directory,
    require_regular_file,
    require_safe_component,
)
from .profiles import registered_tags, require_valid_profile, tag_groups, validate_record
from .tree import inventory_unit
from .registry import canonical_registry, require_registry, resolve_bundle, validate_registry, validate_registry_value, validate_transition
from .validation import ValidationReport, validate_record_directory, validate_workspace


@dataclass
class Outcome:
    status: Status = Status.OK
    data: dict[str, Any] = field(default_factory=dict)
    issues: list[dict[str, Any]] = field(default_factory=list)


def _raise_invalid_report(report: ValidationReport) -> None:
    if report.issues:
        raise CortexError(
            "Workspace validation failed",
            status=Status.VALIDATION_ERROR,
            code="workspace_invalid",
            details={"issues": report.issues},
        )


def _now() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%S.%fZ")


def _atomic_replace_json(path: Path, value: dict[str, Any], purpose: str) -> None:
    try:
        payload = json_bytes(value)
    except UnicodeEncodeError as exc:
        raise validation_error("Owned JSON contains text that is not valid UTF-8", "invalid_utf8_text", path=str(path)) from exc
    temporary = path.parent / f".cortex-{purpose}-{uuid.uuid4().hex}.tmp"
    temporary_created = False
    try:
        with temporary.open("xb") as stream:
            temporary_created = True
            stream.write(payload)
            stream.flush()
        os.replace(native_path(temporary), native_path(path))
    except OSError as exc:
        if temporary_created:
            try:
                temporary.unlink(missing_ok=True)
            except OSError as cleanup_exc:
                raise io_error(
                    "Owned temporary file could not be cleaned",
                    "cleanup_failed",
                    path=str(temporary),
                    os_error=str(cleanup_exc),
                ) from cleanup_exc
        raise io_error("Owned JSON file could not be replaced", "replace_failed", path=str(path), os_error=str(exc)) from exc


def _cleanup_staged_directory(path: Path) -> None:
    if not exists(path):
        return
    import shutil

    try:
        shutil.rmtree(native_path(path))
    except OSError as exc:
        raise io_error("Owned staged directory could not be cleaned", "cleanup_failed", path=str(path), os_error=str(exc)) from exc


def _read_operand_again(operand: str, cached: dict[str, Any]) -> dict[str, Any]:
    if operand == "-":
        return cached
    return read_json_operand(operand)[0]


def _precheck_metadata_shape(value: dict[str, Any]) -> None:
    allowed = set(RECORD_FIELDS)
    unknown = sorted(set(value) - allowed)
    if unknown:
        raise validation_error("Metadata contains unknown fields", "unknown_field", fields=unknown)
    missing = sorted({"title", "tags"} - set(value))
    if missing:
        raise validation_error("Metadata is missing required fields", "missing_field", fields=missing)


def _complete_metadata(
    value: dict[str, Any],
    registered: set[str],
    *,
    auto_timestamp: bool = True,
) -> dict[str, Any]:
    _precheck_metadata_shape(value)
    candidate = {
        "title": value.get("title"),
        "timestamp": value.get("timestamp", _now() if auto_timestamp else None),
        "tags": value.get("tags"),
    }
    problems = validate_record(candidate, registered, label="metadata")
    if problems:
        first = problems[0]
        raise validation_error(first["message"], first["code"], path=first.get("path"), issues=problems)
    return candidate


def _naming_tag_for_record(record: dict[str, Any], tags: dict[str, Any], layout: dict[str, Any]) -> tuple[str, set[str]]:
    group_name = layout["unit_name_tag_group"]
    if group_name is None:
        raise validation_error("Bundle must be configured before records can be added", "bundle_not_operational")
    groups = tag_groups(tags)
    if group_name not in groups:
        raise validation_error("unit_name_tag_group does not name an existing tag group", "unknown_unit_name_tag_group", group=group_name)
    naming_tags = {item["tag"] for item in groups[group_name]}
    selected = [tag for tag in record["tags"] if tag in naming_tags]
    if len(selected) != 1:
        raise validation_error(
            "Record must contain exactly one tag from the configured naming group",
            "unit_name_tag_count",
            tags=selected,
        )
    return selected[0], naming_tags


def _record_operand(value: str) -> str:
    if "\\" in value or "/" in value or value in {"", ".", ".."}:
        raise validation_error("Record operand must be one exact safe component", "invalid_record_operand", path=value)
    require_safe_component(value, allow_profiles=False, label=value)
    return value


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with open(native_path(path), "rb") as stream:
        while block := stream.read(1024 * 1024):
            digest.update(block)
    return digest.hexdigest()


def _residue_count(root: Path) -> int:
    count = 1
    def visit(directory: Path) -> None:
        nonlocal count
        for entry in os.scandir(native_path(directory)):
            count += 1
            meta = entry.stat(follow_symlinks=False)
            if is_reparse_metadata(meta):
                continue
            if stat.S_ISDIR(meta.st_mode):
                visit(Path(entry.path))
    visit(root)
    return count


def _conversion_shape(entries: list[tuple[str, Path, bool]], source: Path) -> None:
    files = [relative for relative, _path, directory in entries if not directory]
    if any(relative.casefold() == "record.json" for relative in files):
        raise validation_error(
            "Converter payload must not contain reserved Cortex record.json",
            "reserved_record_metadata",
            path="record.json",
        )
    roots = {relative.split("/", 1)[0] for relative, _path, _directory in entries}
    top_md = [name for name in files if "/" not in name and name.casefold().endswith(".md")]
    top_json = [name for name in files if "/" not in name and name.casefold().endswith(".json")]
    src_files = [name for name in files if name.startswith("src/") and name.count("/") == 1]
    allowed = {top_md[0] if top_md else "", top_json[0] if top_json else "", src_files[0] if src_files else ""}
    other = [name for name in files if name not in allowed and not name.startswith("assets/")]
    if len(top_md) != 1 or len(top_json) != 1 or Path(top_md[0]).stem != Path(top_json[0]).stem or len(src_files) != 1 or other or not roots <= {top_md[0], top_json[0], "src", "assets"}:
        raise validation_error("Conversion must have the exact canonical full bundle shape", "invalid_conversion_shape")
    converted_source = next(path for relative, path, directory in entries if not directory and relative == src_files[0])
    if Path(src_files[0]).name != source.name or _sha256(converted_source) != _sha256(source):
        raise validation_error("--source must equal conversion src by basename and SHA-256", "conversion_source_mismatch")


def _safe_source(source_text: str) -> Path:
    if source_text == "-":
        raise usage_error("--source does not support stdin", "source_stdin_unsupported")
    source = Path(os.path.abspath(source_text))
    require_regular_file(source, code="source_not_ordinary")
    require_safe_component(source.name, label=source.name)
    return source


def _safe_conversion(conversion_text: str | None) -> tuple[Path | None, list[tuple[str, Path, bool]] | None]:
    if conversion_text is None:
        return None, None
    if conversion_text == "-":
        raise usage_error("--conversion does not support stdin", "conversion_stdin_unsupported")
    conversion = Path(os.path.abspath(conversion_text))
    _, entries = inspect_conversion(conversion)
    return conversion, entries


def _require_initialized_lock_target(workspace: Path) -> None:
    target = workspace / "profiles" / "record-schema.json"
    if not exists(target):
        raise validation_error("Workspace is not initialized", "workspace_not_initialized", path=str(workspace))
    require_regular_file(target, code="invalid_lock_target")


class CortexService:
    def __init__(self, workspace: Path | str, *, kb_root: Path | str | None = None, bundle_id: str | None = None) -> None:
        self.workspace = Path(os.path.abspath(workspace))
        self.kb_root = Path(os.path.abspath(kb_root)) if kb_root is not None else None
        self.bundle_id = bundle_id

    def _lock_path(self) -> Path:
        if self.kb_root is not None:
            return self.kb_root / ROOT_LOCK_FILENAME
        return workspace_lock_path(self.workspace)

    def _refresh_managed_workspace(self) -> None:
        if self.kb_root is None:
            return
        assert self.bundle_id is not None
        registry = require_registry(self.kb_root)
        entry = resolve_bundle(self.kb_root, self.bundle_id, registry=registry)
        selected = self.kb_root / entry["path"]
        if selected != self.workspace:
            raise validation_error("Bundle resolution changed before mutation", "bundle_resolution_changed", id=self.bundle_id)

    @contextmanager
    def _mutation_report(self) -> Iterator[ValidationReport]:
        _require_initialized_lock_target(self.workspace)
        lock_path = self._lock_path()
        with writer_lock(lock_path) as lock_stream:
            self._refresh_managed_workspace()
            locked_schema = None
            if lock_path == self.workspace / "profiles" / "record-schema.json":
                lock_stream.seek(0)
                locked_schema = lock_stream.read()
            report = validate_workspace(self.workspace, locked_record_schema=locked_schema)
            _raise_invalid_report(report)
            yield report

    def init(self) -> Outcome:
        root_lock = self.workspace.parent / ROOT_LOCK_FILENAME
        if exists(root_lock):
            with writer_lock(workspace_lock_path(self.workspace)):
                return self._init_unlocked()
        return self._init_unlocked()

    def _init_unlocked(self) -> Outcome:
        root = self.workspace
        if exists(root):
            require_real_directory(root, code="workspace_not_directory")
            if checked_scandir(root):
                raise validation_error("Workspace must be absent or exactly empty", "workspace_not_empty", path=str(root))
        else:
            parent = root.parent
            require_real_directory(parent, code="workspace_parent_not_directory")
            reject_reparse_ancestry(parent)
            try:
                root.mkdir(exist_ok=False)
            except OSError as exc:
                raise io_error("Workspace directory could not be created", "init_failed", path=str(root), os_error=str(exc)) from exc
        try:
            profiles = root / "profiles"
            profiles.mkdir(exist_ok=False)
            for name, value in (
                ("record-schema.json", RECORD_SCHEMA),
                ("tags.json", DEFAULT_TAGS),
                ("layout.json", DEFAULT_LAYOUT),
            ):
                with (profiles / name).open("xb") as stream:
                    stream.write(json_bytes(value))
                    stream.flush()
        except OSError as exc:
            raise io_error("Workspace profiles could not be initialized", "init_failed", path=str(root), os_error=str(exc)) from exc
        return Outcome(data={"version": VERSION, "unit_name_tag_group": None})

    def status(self) -> Outcome:
        report = validate_workspace(self.workspace)
        return Outcome(data={"version": VERSION, "valid": report.valid, "count": report.count})

    def validate(self) -> Outcome:
        report = validate_workspace(self.workspace)
        data = {"version": VERSION, "valid": report.valid, "count": report.count}
        if report.valid:
            return Outcome(data=data)
        return Outcome(status=Status.VALIDATION_ERROR, data=data, issues=report.issues)

    def config_show(self, profile: str) -> Outcome:
        report = validate_workspace(self.workspace)
        _raise_invalid_report(report)
        value = RECORD_SCHEMA if profile == "record" else report.tags if profile == "tags" else report.layout
        assert value is not None
        return Outcome(data={"profile": profile, "value": value})

    def config_set(self, profile: str, operand: str) -> Outcome:
        value, _ = read_json_operand(operand)
        require_valid_profile(profile, value)
        with self._mutation_report() as report:
            value = _read_operand_again(operand, value)
            require_valid_profile(profile, value)
            if profile == "layout" and report.count and value != report.layout:
                raise validation_error("Layout is immutable after the first record", "layout_change_forbidden")
            candidate_report = validate_workspace(
                self.workspace,
                locked_record_schema=json_bytes(RECORD_SCHEMA),
                tags_override=value if profile == "tags" else None,
                layout_override=value if profile == "layout" else None,
            )
            _raise_invalid_report(candidate_report)
            return self._set_profile(profile, value)

    def _set_profile(self, profile: str, value: dict[str, Any]) -> Outcome:
        _atomic_replace_json(self.workspace / "profiles" / f"{profile}.json", value, profile)
        return Outcome(data={"profile": profile, "value": value})

    def record_add(self, source_operand: str, conversion_operand: str | None, metadata_operand: str) -> Outcome:
        metadata, _ = read_json_operand(metadata_operand)
        _precheck_metadata_shape(metadata)
        _safe_source(source_operand)
        _safe_conversion(conversion_operand)
        with self._mutation_report() as report:
            assert report.tags is not None and report.layout is not None
            if report.layout["unit_name_tag_group"] is None:
                raise validation_error("Bundle must be configured before records can be added", "bundle_not_operational")
            metadata = _read_operand_again(metadata_operand, metadata)
            registered = registered_tags(report.tags)
            layout = report.layout
            record = _complete_metadata(metadata, registered, auto_timestamp=False)
            naming_tag, _naming_tags = _naming_tag_for_record(record, report.tags, report.layout)
            source = _safe_source(source_operand)
            _, conversion_entries = _safe_conversion(conversion_operand)
            if conversion_entries is None and source.suffix.casefold() != ".md":
                raise validation_error("Markdown-only add requires a .md source", "invalid_source_only")
            if conversion_entries is not None:
                _conversion_shape(conversion_entries, source)
            folder = tag_title_date_name(naming_tag, record["title"], record["timestamp"], layout["max_component_length"])
            existing = {entry.name.casefold() for entry in checked_scandir(self.workspace) if entry.name != "profiles"}
            if folder.casefold() in existing:
                raise validation_error("Record folder already exists", "duplicate_record_name", path=folder)
            temporary = self.workspace / f".cortex-add-{uuid.uuid4().hex}"
            destination = self.workspace / folder
            staged_unit = temporary
            temporary_created = False
            try:
                temporary.mkdir(exist_ok=False)
                temporary_created = True
                with (staged_unit / "record.json").open("xb") as stream:
                    stream.write(json_bytes(record))
                    stream.flush()
                if conversion_entries is not None:
                    for relative, item_source, directory in conversion_entries:
                        target = staged_unit.joinpath(*relative.split("/"))
                        if directory:
                            target.mkdir(exist_ok=False)
                        else:
                            copy_regular(item_source, target)
                else:
                    copy_regular(source, staged_unit / source.name)
                problems = validate_record_directory(
                    staged_unit,
                    folder,
                    registered=registered,
                    maximum=layout["max_component_length"],
                    tags=report.tags,
                    layout=layout,
                    check_folder=False,
                )
                if problems:
                    first = problems[0]
                    raise validation_error(first["message"], first["code"], path=first.get("path"), issues=problems)
                try:
                    rename_no_replace(temporary, destination)
                except FileExistsError:
                    raise validation_error("Record folder already exists", "duplicate_record_name", path=folder)
            except CortexError:
                if temporary_created:
                    _cleanup_staged_directory(temporary)
                raise
            except OSError as exc:
                if temporary_created:
                    _cleanup_staged_directory(temporary)
                raise io_error("Record could not be staged", "record_stage_failed", path=str(destination), os_error=str(exc)) from exc
            return Outcome(data={"record": folder, "path": folder})

    def record_edit(self, folder: str, metadata_operand: str) -> Outcome:
        unit = _record_operand(folder)
        metadata, _ = read_json_operand(metadata_operand)
        _precheck_metadata_shape(metadata)
        with self._mutation_report() as report:
            assert report.tags is not None and report.layout is not None
            metadata = _read_operand_again(metadata_operand, metadata)
            _precheck_metadata_shape(metadata)
            unit_path = self.workspace / unit
            if not exists(unit_path):
                raise validation_error("Record folder does not exist", "record_not_found", path=folder)
            record_path = unit_path / "record.json"
            registered = registered_tags(report.tags)
            record = _complete_metadata(metadata, registered, auto_timestamp=False)
            current = read_json_operand(str(record_path))[0]
            old_tag, _ = _naming_tag_for_record(current, report.tags, report.layout)
            new_tag, _ = _naming_tag_for_record(record, report.tags, report.layout)
            if record["title"] != current["title"] or record["timestamp"] != current["timestamp"] or new_tag != old_tag:
                raise validation_error("Title, timestamp, and selected naming tag are immutable", "record_identity_change_forbidden", path=folder)
            _atomic_replace_json(record_path, record, "edit")
            return Outcome(data={"record": folder, "path": folder})

    def record_show(self, folder: str) -> Outcome:
        unit = _record_operand(folder)
        with self._mutation_report() as report:
            unit_path = self.workspace / unit
            if not exists(unit_path):
                raise validation_error("Record folder does not exist", "record_not_found", path=folder)
            inventory = inventory_unit(unit_path, unit)
            record_bytes = (unit_path / "record.json").read_bytes()
            metadata = loads_object(record_bytes, label=f"{unit}/record.json")
            confirmation = inventory_unit(unit_path, unit)
            if confirmation.sha256 != inventory.sha256 or confirmation.manifest != inventory.manifest:
                raise validation_error("Unit changed while record metadata was read", "tree_changed_during_read", path=unit)
            return Outcome(data={
                "record": unit,
                "tree_sha256": inventory.sha256,
                "record_json_sha256": hashlib.sha256(record_bytes).hexdigest(),
                "metadata": metadata,
                "manifest": [{"path": item.relative, "type": item.kind, **({"size": item.size} if item.size is not None else {})} for item in inventory.manifest],
            })

    def record_delete(self, folder: str, expected: str) -> Outcome:
        unit = _record_operand(folder)
        if len(expected) != 64 or expected.lower() != expected or any(ch not in "0123456789abcdef" for ch in expected):
            raise validation_error("Expected tree digest must be lowercase 64-character SHA-256", "invalid_expected_tree_sha256")
        with self._mutation_report() as report:
            unit_path = self.workspace / unit
            if not exists(unit_path):
                raise validation_error("Record folder does not exist", "record_not_found", path=unit)
            inventory = inventory_unit(unit_path, unit)
            if inventory.sha256 != expected:
                raise validation_error("Unit tree digest does not match", "tree_digest_mismatch", expected=expected, actual=inventory.sha256)
            ordered = sorted(inventory.manifest, key=lambda item: (item.relative.count("/"), item.relative.encode("utf-8")), reverse=True)
            first_failed = None
            try:
                for item in ordered:
                    path = unit_path.joinpath(*item.relative.split("/"))
                    first_failed = item.relative
                    meta = os.lstat(native_path(path))
                    if is_reparse_metadata(meta) or (item.kind == "file" and not stat.S_ISREG(meta.st_mode)) or (item.kind == "directory" and not stat.S_ISDIR(meta.st_mode)):
                        raise OSError("authorized entry type changed")
                    if item.kind == "file":
                        os.unlink(native_path(path))
                    else:
                        os.rmdir(native_path(path))
                first_failed = "."
                os.rmdir(native_path(unit_path))
            except OSError as exc:
                try:
                    remaining = _residue_count(unit_path) if exists(unit_path) else 0
                    issues = [{"code": "delete_incomplete", "message": "Record deletion stopped at first failure", "path": first_failed or ".", "details": {"os_error": str(exc)}}]
                except OSError as scan_exc:
                    remaining = None
                    issues = [
                        {"code": "delete_incomplete", "message": "Record deletion stopped at first failure", "path": first_failed or ".", "details": {"os_error": str(exc)}},
                        {"code": "residue_unreadable", "message": "Deletion residue could not be counted", "details": {"os_error": str(scan_exc)}},
                    ]
                return Outcome(status=Status.IO_ERROR, data={"record": unit, "partial": True, "first_failed_relative_path": first_failed or ".", "remaining_entry_count": remaining}, issues=issues)
            return Outcome(data={"record": unit, "deleted": True, "tree_sha256": expected})


class RegistryService:
    def __init__(self, root: Path | str) -> None:
        self.root = Path(os.path.abspath(root))

    def show(self) -> Outcome:
        value = require_registry(self.root)
        return Outcome(data={"registry": value})

    def validate(self) -> Outcome:
        report = validate_registry(self.root)
        count = len(report.value["bundles"]) if report.value is not None and isinstance(report.value.get("bundles"), list) else 0
        data = {"version": VERSION, "valid": report.valid, "bundles": count}
        if report.valid:
            return Outcome(data=data)
        return Outcome(status=Status.VALIDATION_ERROR, data=data, issues=report.issues)

    def resolve(self, bundle_id: str) -> Outcome:
        registry = require_registry(self.root)
        entry = resolve_bundle(self.root, bundle_id, registry=registry)
        return Outcome(data={"bundle_id": entry["id"], "path": entry["path"], "workspace": str(self.root / entry["path"]), "description": entry["description"]})

    def _current_for_candidate(self, candidate: dict[str, Any]) -> dict[str, Any]:
        report = validate_registry(self.root)
        candidate_paths = {entry["path"] for entry in candidate["bundles"]}
        blocking = [
            item
            for item in report.issues
            if not (item["code"] == "orphan_bundle" and item.get("path") in candidate_paths)
        ]
        if blocking:
            first = blocking[0]
            raise validation_error(first["message"], first["code"], path=first.get("path"), issues=blocking)
        if report.value is None:
            raise validation_error("Registry is not readable", "registry_unreadable", path=REGISTRY_FILENAME)
        return report.value

    def set(self, operand: str) -> Outcome:
        candidate_input, _ = read_json_operand(operand)
        syntax_problems = validate_registry_value(candidate_input)
        if syntax_problems:
            first = syntax_problems[0]
            raise validation_error(first["message"], first["code"], path=first.get("path"), issues=syntax_problems)
        candidate = canonical_registry(candidate_input)
        current_path = self.root / REGISTRY_FILENAME
        if exists(current_path):
            transition_problems = validate_transition(self._current_for_candidate(candidate), candidate)
            if transition_problems:
                first = transition_problems[0]
                raise validation_error(first["message"], first["code"], path=first.get("path"), issues=transition_problems)
        static = validate_registry(self.root, value_override=candidate_input)
        if static.issues:
            first = static.issues[0]
            raise validation_error(first["message"], first["code"], path=first.get("path"), issues=static.issues)

        assert static.value is not None
        candidate = static.value
        lock_path = self.root / ROOT_LOCK_FILENAME
        if not exists(lock_path):
            try:
                with lock_path.open("xb"):
                    pass
            except FileExistsError:
                pass
            except OSError as exc:
                raise io_error("KB-root lock could not be created", "lock_create_failed", path=str(lock_path), os_error=str(exc)) from exc
        require_regular_file(lock_path, code="invalid_root_lock")
        try:
            if lock_path.stat().st_size != 0:
                raise validation_error("KB-root lock must remain zero bytes", "invalid_root_lock", path=str(lock_path))
        except OSError as exc:
            raise io_error("KB-root lock could not be inspected", "lock_target_unreadable", path=str(lock_path), os_error=str(exc)) from exc
        with writer_lock(lock_path):
            candidate_input = _read_operand_again(operand, candidate)
            checked = validate_registry(self.root, value_override=candidate_input)
            if checked.issues:
                first = checked.issues[0]
                raise validation_error(first["message"], first["code"], path=first.get("path"), issues=checked.issues)
            assert checked.value is not None
            candidate = checked.value
            current_path = self.root / REGISTRY_FILENAME
            current: dict[str, Any] | None = None
            if exists(current_path):
                current = self._current_for_candidate(candidate)
            problems: list[dict[str, Any]] = []
            if current is not None:
                problems.extend(validate_transition(current, candidate))
            if problems:
                first = problems[0]
                raise validation_error(first["message"], first["code"], path=first.get("path"), issues=problems)
            if current is None:
                try:
                    with current_path.open("xb") as stream:
                        stream.write(json_bytes(candidate))
                        stream.flush()
                except FileExistsError as exc:
                    raise CortexError("Registry was concurrently created", status=Status.BUSY, code="registry_busy", path=str(current_path)) from exc
                except OSError as exc:
                    raise io_error("Registry could not be created", "registry_create_failed", path=str(current_path), os_error=str(exc)) from exc
            else:
                _atomic_replace_json(current_path, candidate, "registry")
        return Outcome(data={"registry": candidate})


__all__ = ["CortexService", "Outcome", "RegistryService"]
